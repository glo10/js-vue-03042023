# API

[https://open.er-api.com/v6/latest/USD](https://open.er-api.com/v6/latest/USD)